# Large UI pieces v1

这里是上一张神通完整界面里缺失的三块大素材：

- left-parent-navigation-panel：角色父页面左侧整条导航面板，含八个空标签位和一个选中态槽位；
- learned-ability-library-panel：已悟神通完整列表面板，含筛选条、卡片网格与滚动条；
- ability-detail-panel：右侧完整神通详情面板，含插画窗、标题区、属性行及主次按钮位。

PNG 为 RGBA 透明图。面板内部的纸张、深色玉面和金线属于皮肤本体；面板外部透明。文字、图标、技能图片和状态由 Unity 内容层叠加。
