InkOrnate v1: merge the enclosed Assets folder into your Unity project.
12 transparent sprites, 3 palettes x 4 states; no text baked in.
Image Type: Sliced. Button Transition: SpriteSwap. Normal sprite on Image; hover on Highlighted and Selected; pressed on Pressed; disabled on Disabled.
Borders L120 B28 R120 T28, PPU100, FullRect, MipMaps off, Clamp, Alpha Is Transparency on.
Recommended button height 48-64 screen pixels. Tune pixelsPerUnitMultiplier to 2.5-3.0 if needed.
Generated state artwork may have small ornament differences. Review state transitions before shipping. No scenes or scripts included.
